#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

//#define SAVE

#ifdef SAVE
#define img_output(N, I) (cv::imwrite(N, I))
#define EXT ".jpg"
#else
#define img_output(N, I) (cv::imshow(N, I))
#define EXT
#endif

#define W 640
#define H 640

using std::cout;
using std::cerr;
using std::endl;
using std::vector;

typedef std::vector<cv::Point2f> points_vector;

int main(void) {
  struct stat           s;
  FILE *                f;
  vector<char>          buffer;
  vector<unsigned char> out_buffer;

  /////////////////////////////////////////////////////////////////
  // Declare the matrices.
  /////////////////////////////////////////////////////////////////
  cv::Mat A, B, C;

  /////////////////////////////////////////////////////////////////
  // Load two images using the simplest method.
  /////////////////////////////////////////////////////////////////
  A = cv::imread("queen1.jpg");
  B = cv::imread("queen2.jpg");

  /////////////////////////////////////////////////////////////////
  // Load an image from a byte array.
  /////////////////////////////////////////////////////////////////
  stat("queen3.jpg", &s);

  // Load the byte array.
  f = fopen("queen3.jpg", "r");
  for(int i = 0; i < s.st_size; i++) {
    buffer.push_back((char)fgetc(f));
  }
  fclose(f);
  
  // Decode the byte array.
  C = cv::imdecode(buffer, 1);
  img_output("Decoded" EXT, C);

  // Reencode the byte array in another format.
  if(cv::imencode(".ppm", C, out_buffer)) {

    // If success then save the reencoded byte array.
    cout << "Encoded!" << endl;
    f = fopen("C.ppm", "w");
    for(int i = 0; i < out_buffer.size(); i++) {
      fputc(out_buffer[i], f);
    }
    fclose(f);

  } else {
    cerr << "Encoding failed" << endl;
  }

  /////////////////////////////////////////////////////////////////
  // This will throw an exception because the images are of
  // different size.
  /////////////////////////////////////////////////////////////////
  try {
    img_output("A+B" EXT, A + B);
  } catch(cv::Exception e) {
    cerr << e.err << endl;
  }

  /////////////////////////////////////////////////////////////////
  // Make both images the same size.
  /////////////////////////////////////////////////////////////////
  cv::resize(A, A, cv::Size(W, H));
  cv::resize(B, B, cv::Size(W, H));

  /////////////////////////////////////////////////////////////////
  // Matrix operations.
  /////////////////////////////////////////////////////////////////
  img_output("A+B" EXT, A + B);
  img_output("A-B" EXT, A - B);
  img_output("1-A" EXT, cv::Mat(W, H, CV_8UC3, cv::Scalar(255,255,255)) - A);
  img_output("AgtB" EXT, A > B);
  img_output("AltB" EXT, A < B);
  img_output("AgteB" EXT, A >= B);
  img_output("AlteB" EXT, A <= B);
  img_output("AdiffB" EXT, A != B);
  img_output("AeqB" EXT, A == B);
  img_output("Transpose_A" EXT, A.t());

  /////////////////////////////////////////////////////////////////
  // Image Processing.
  /////////////////////////////////////////////////////////////////
  cv::Mat gray, thresh;

  cv::cvtColor(A, gray, CV_BGR2GRAY);
  img_output("Gray" EXT, gray);

  cv::threshold(gray, thresh, 128, 255, cv::THRESH_OTSU);
  img_output("Threshold" EXT, thresh);

  cv::adaptiveThreshold(gray, thresh, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY_INV, 7, 7);
  img_output("Adaptive Threshold" EXT, thresh);

  cv::Mat bin;
  cv::Size markerSize(W, H);
  points_vector v, m;

  // Assemble a unitary reference polygon.
  m.push_back(cv::Point2f(0,0));
  m.push_back(cv::Point2f(markerSize.width-1,0));
  m.push_back(cv::Point2f(markerSize.width-1,markerSize.height-1));
  m.push_back(cv::Point2f(0,markerSize.height-1));

  v.push_back(cv::Point2f(0, 0));
  v.push_back(cv::Point2f(markerSize.width - 1, -markerSize.height));
  v.push_back(cv::Point2f(markerSize.width - 1, markerSize.height * 2));
  v.push_back(cv::Point2f(0, markerSize.height - 1));
  
  // Warp the input image's perspective to transform it into the reference
  // polygon's perspective.
  cv::Mat M = cv::getPerspectiveTransform(m, v);
  cv::warpPerspective(gray, bin, M, markerSize);
  img_output("Perspective" EXT, bin);

  cv::medianBlur(A, thresh, 15);
  img_output("Median" EXT, thresh);

  /////////////////////////////////////////////////////////////////
  // Deallocate the matrices.
  /////////////////////////////////////////////////////////////////
  // Initialize a Mat with another.
  cv::Mat D(C);

  A.release();
  B.release();
  C.release();

  if(A.data == NULL && B.data == NULL && C.data == NULL) {
    cout << "Deallocated!" << endl;
  } else {
    cout << "Could not deallocate!" << endl;
  }

  /////////////////////////////////////////////////////////////////
  // Block the application so that Highgui can show the windows.
  /////////////////////////////////////////////////////////////////
  cv::waitKey(0);

  /////////////////////////////////////////////////////////////////
  // Bye!
  /////////////////////////////////////////////////////////////////
  return EXIT_SUCCESS;
}
